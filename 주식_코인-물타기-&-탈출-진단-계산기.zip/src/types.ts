export type AssetMode = 'stock_krw' | 'stock_usd' | 'crypto';

export interface PurchaseTier {
  id: string;
  tierNumber: number;
  quantity: number | '';
  price: number | '';
}

export interface CalculatorState {
  assetMode: AssetMode;
  currentQuantity: number | '';
  currentAvgPrice: number | '';
  tiers: PurchaseTier[];
  targetExitPrice: number | '';
}

export type DiagnosisLevel = 'easy' | 'moderate' | 'cautious' | 'high_risk' | 'invalid';

export interface CalculationResult {
  initialTotalQuantity: number;
  initialTotalInvestment: number;
  additionalTotalQuantity: number;
  additionalTotalInvestment: number;
  finalTotalQuantity: number;
  finalTotalInvestment: number;
  finalAvgPrice: number;
  avgPriceReductionPercent: number; // e.g. 15.2 (% reduced)
  requiredRiseBefore: number; // % rise needed from target price before averaging down
  requiredRiseAfter: number; // % rise needed from target price after averaging down
  riseEasing: number; // percentage points reduced in needed rise
  targetProfitLossAmount: number; // P&L amount at target exit price
  targetProfitLossRate: number; // P&L rate (%) at target exit price
  diagnosisLevel: DiagnosisLevel;
  diagnosisTitle: string;
  diagnosisMessage: string;
  diagnosisBadgeClass: string;
}

export interface CurrencyConfig {
  symbol: string;
  code: string;
  decimals: number;
  unitName: string; // '주' or '개'
}
