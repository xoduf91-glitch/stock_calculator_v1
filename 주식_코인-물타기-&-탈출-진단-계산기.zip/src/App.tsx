import React, { useState, useMemo } from 'react';
import { AssetMode, CalculatorState, PurchaseTier } from './types';
import { calculateAvgPrice, ASSET_CONFIGS, formatCurrency, formatNumber } from './utils/calculator';
import { Header } from './components/Header';
import { HoldingsInput } from './components/HoldingsInput';
import { TierInputList } from './components/TierInputList';
import { ExitTargetInput } from './components/ExitTargetInput';
import { ResultDashboard } from './components/ResultDashboard';
import { SeoGuideContent } from './components/SeoGuideContent';
import { Footer } from './components/Footer';

export default function App() {
  const [assetMode, setAssetMode] = useState<AssetMode>('stock_krw');
  const [currentQuantity, setCurrentQuantity] = useState<number | ''>('');
  const [currentAvgPrice, setCurrentAvgPrice] = useState<number | ''>('');
  const [targetExitPrice, setTargetExitPrice] = useState<number | ''>('');

  const [tiers, setTiers] = useState<PurchaseTier[]>([]);

  const [copied, setCopied] = useState(false);

  const calculatorState: CalculatorState = useMemo(() => {
    return {
      assetMode,
      currentQuantity,
      currentAvgPrice,
      tiers,
      targetExitPrice,
    };
  }, [assetMode, currentQuantity, currentAvgPrice, tiers, targetExitPrice]);

  const result = useMemo(() => {
    return calculateAvgPrice(calculatorState);
  }, [calculatorState]);

  // Asset mode change handler with clean empty resets
  const handleAssetModeChange = (mode: AssetMode) => {
    setAssetMode(mode);
    setCurrentAvgPrice('');
    setCurrentQuantity('');
    setTargetExitPrice('');
    setTiers([]);
  };

  // Add Tier Row
  const handleAddTier = () => {
    const nextTierNumber = tiers.length + 2; // 1st is holding, so 2nd, 3rd, 4th...
    const newTier: PurchaseTier = {
      id: `tier-${Date.now()}`,
      tierNumber: nextTierNumber,
      quantity: typeof currentQuantity === 'number' ? currentQuantity : '',
      price: typeof currentAvgPrice === 'number' && currentAvgPrice > 0 ? Math.round(currentAvgPrice * 0.9) : '',
    };
    setTiers([...tiers, newTier]);
  };

  // Remove Tier Row
  const handleRemoveTier = (id: string) => {
    const updated = tiers.filter((t) => t.id !== id);
    // Re-index tier numbers
    const reindexed = updated.map((t, idx) => ({
      ...t,
      tierNumber: idx + 2,
    }));
    setTiers(reindexed);
  };

  // Update Tier Fields
  const handleUpdateTier = (id: string, field: 'quantity' | 'price', value: number | '') => {
    setTiers(
      tiers.map((t) => (t.id === id ? { ...t, [field]: value } : t))
    );
  };

  // Preset Buttons for Tier
  const handleApplyPreset = (tierId: string, type: 'minus10' | 'minus20' | 'matchQty') => {
    if (typeof currentAvgPrice !== 'number' || currentAvgPrice <= 0) return;

    setTiers(
      tiers.map((t) => {
        if (t.id !== tierId) return t;
        if (type === 'minus10') {
          return { ...t, price: Math.round(currentAvgPrice * 0.9) };
        }
        if (type === 'minus20') {
          return { ...t, price: Math.round(currentAvgPrice * 0.8) };
        }
        if (type === 'matchQty' && typeof currentQuantity === 'number') {
          return { ...t, quantity: currentQuantity };
        }
        return t;
      })
    );
  };

  // Quick Set Target Exit Price
  const handleQuickSetTarget = (multiplier: number) => {
    if (result.finalAvgPrice > 0) {
      const config = ASSET_CONFIGS[assetMode];
      if (config.decimals > 0) {
        setTargetExitPrice(parseFloat((result.finalAvgPrice * multiplier).toFixed(config.decimals)));
      } else {
        setTargetExitPrice(Math.round(result.finalAvgPrice * multiplier));
      }
    }
  };

  // Reset All Inputs
  const handleReset = () => {
    setCurrentQuantity('');
    setCurrentAvgPrice('');
    setTargetExitPrice('');
    setTiers([]);
  };

  // Copy Result Text to Clipboard
  const handleCopyShareText = () => {
    const modeName =
      assetMode === 'stock_krw'
        ? '국내 주식 (원화)'
        : assetMode === 'stock_usd'
        ? '해외 주식 (달러)'
        : '암호화폐/코인';

    const shareUrl = window.location.href;

    const summaryText = `📊 [주식/코인 물타기 & 탈출 진단 결과]
────────────────────
• 구분: ${modeName}
• 기존 평단가: ${formatCurrency(currentAvgPrice || 0, assetMode)} (${formatNumber(currentQuantity || 0, ASSET_CONFIGS[assetMode].decimals)}${ASSET_CONFIGS[assetMode].unitName})
• 추가 매수: ${formatNumber(result.additionalTotalQuantity, ASSET_CONFIGS[assetMode].decimals)}${ASSET_CONFIGS[assetMode].unitName} (+${formatCurrency(result.additionalTotalInvestment, assetMode)})
────────────────────
✨ [최종 예상 평단가]: ${formatCurrency(result.finalAvgPrice, assetMode)} (-${result.avgPriceReductionPercent.toFixed(1)}% 낮춤!)
🎯 [설정 목표가]: ${formatCurrency(targetExitPrice || 0, assetMode)}
🚨 [탈출 필요 상승률]: +${result.requiredRiseAfter.toFixed(1)}% 필요 (기존 +${result.requiredRiseBefore.toFixed(1)}% → +${result.requiredRiseAfter.toFixed(1)}%로 난이도 완화)
🟢 진단: ${result.diagnosisTitle}
────────────────────
👉 나도 내 주식/코인 평단가 계산하기: ${shareUrl}`;

    navigator.clipboard.writeText(summaryText).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 3000);
    });
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col justify-between font-sans selection:bg-indigo-500 selection:text-white">
      <div>
        <Header
          assetMode={assetMode}
          onAssetModeChange={handleAssetModeChange}
          onReset={handleReset}
        />

        <main className="max-w-6xl mx-auto px-4 sm:px-8 py-8 lg:py-12 relative z-20">
          {/* Main 2-Column Responsive Layout */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            {/* Left Main Controls Column */}
            <div className="lg:col-span-7 space-y-6">
              {/* 1. Initial Position */}
              <HoldingsInput
                assetMode={assetMode}
                currentQuantity={currentQuantity}
                currentAvgPrice={currentAvgPrice}
                onChangeQuantity={setCurrentQuantity}
                onChangeAvgPrice={setCurrentAvgPrice}
              />

              {/* 2. Additional Tiers */}
              <TierInputList
                assetMode={assetMode}
                tiers={tiers}
                currentAvgPrice={currentAvgPrice}
                currentQuantity={currentQuantity}
                onAddTier={handleAddTier}
                onRemoveTier={handleRemoveTier}
                onUpdateTier={handleUpdateTier}
                onApplyPreset={handleApplyPreset}
              />

              {/* 3. Exit Diagnosis & Target */}
              <ExitTargetInput
                assetMode={assetMode}
                targetExitPrice={targetExitPrice}
                calculationResult={result}
                onChangeTargetExitPrice={setTargetExitPrice}
                onQuickSetTarget={handleQuickSetTarget}
              />
            </div>

            {/* Right Sticky Calculation Dashboard Column */}
            <div className="lg:col-span-5">
              <ResultDashboard
                assetMode={assetMode}
                calculationResult={result}
                onReset={handleReset}
                onCopyShareText={handleCopyShareText}
                copied={copied}
              />
            </div>
          </div>

          {/* SEO, Principles, Precautions & FAQ Section */}
          <SeoGuideContent />
        </main>
      </div>

      <Footer />
    </div>
  );
}
