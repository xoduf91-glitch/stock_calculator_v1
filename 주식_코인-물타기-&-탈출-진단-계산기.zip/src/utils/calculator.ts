import { CalculatorState, CalculationResult, CurrencyConfig, AssetMode } from '../types';

export const ASSET_CONFIGS: Record<AssetMode, CurrencyConfig> = {
  stock_krw: {
    symbol: '₩',
    code: 'KRW',
    decimals: 0,
    unitName: '주',
  },
  stock_usd: {
    symbol: '$',
    code: 'USD',
    decimals: 2,
    unitName: '주',
  },
  crypto: {
    symbol: '₩',
    code: 'KRW',
    decimals: 4,
    unitName: '개',
  },
};

/**
 * Format numbers with thousand separators and specified currency decimal precision
 */
export function formatCurrency(
  value: number | undefined | null,
  mode: AssetMode = 'stock_krw',
  showSymbol: boolean = true
): string {
  if (value === undefined || value === null || isNaN(value)) {
    return showSymbol ? `${ASSET_CONFIGS[mode].symbol}0` : '0';
  }

  const config = ASSET_CONFIGS[mode];
  const isUSD = mode === 'stock_usd';

  let formatted: string;

  if (isUSD) {
    formatted = value.toLocaleString('en-US', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    });
  } else if (mode === 'crypto') {
    // Check if integer or has fraction
    if (Number.isInteger(value)) {
      formatted = value.toLocaleString('ko-KR');
    } else {
      formatted = value.toLocaleString('ko-KR', {
        minimumFractionDigits: 0,
        maximumFractionDigits: 4,
      });
    }
  } else {
    // KRW stock
    formatted = Math.round(value).toLocaleString('ko-KR');
  }

  return showSymbol ? `${config.symbol}${formatted}` : formatted;
}

export function formatNumber(value: number | undefined | null, decimals: number = 0): string {
  if (value === undefined || value === null || isNaN(value)) return '0';
  return value.toLocaleString('ko-KR', {
    minimumFractionDigits: 0,
    maximumFractionDigits: decimals,
  });
}

export function parseNumberInput(input: string): number | '' {
  if (!input) return '';
  // Remove non-numeric characters except single dot and minus
  const clean = input.replace(/,/g, '').trim();
  const parsed = parseFloat(clean);
  return isNaN(parsed) ? '' : parsed;
}

export function calculateAvgPrice(state: CalculatorState): CalculationResult {
  const currentQty = typeof state.currentQuantity === 'number' ? state.currentQuantity : 0;
  const currentAvg = typeof state.currentAvgPrice === 'number' ? state.currentAvgPrice : 0;
  const targetExit = typeof state.targetExitPrice === 'number' ? state.targetExitPrice : 0;

  const initialTotalInvestment = currentQty * currentAvg;

  let additionalTotalQuantity = 0;
  let additionalTotalInvestment = 0;

  state.tiers.forEach((tier) => {
    const qty = typeof tier.quantity === 'number' ? tier.quantity : 0;
    const prc = typeof tier.price === 'number' ? tier.price : 0;
    if (qty > 0 && prc > 0) {
      additionalTotalQuantity += qty;
      additionalTotalInvestment += qty * prc;
    }
  });

  const finalTotalQuantity = currentQty + additionalTotalQuantity;
  const finalTotalInvestment = initialTotalInvestment + additionalTotalInvestment;

  const finalAvgPrice = finalTotalQuantity > 0 ? finalTotalInvestment / finalTotalQuantity : 0;

  // Percentage reduction in average price
  const avgPriceReductionPercent =
    currentAvg > 0 && finalAvgPrice > 0
      ? ((currentAvg - finalAvgPrice) / currentAvg) * 100
      : 0;

  // Required rise % before and after averaging down from target exit price
  let requiredRiseBefore = 0;
  let requiredRiseAfter = 0;

  if (targetExit > 0) {
    if (currentAvg > 0) {
      requiredRiseBefore = ((currentAvg - targetExit) / targetExit) * 100;
    }
    if (finalAvgPrice > 0) {
      requiredRiseAfter = ((finalAvgPrice - targetExit) / targetExit) * 100;
    }
  }

  const riseEasing = requiredRiseBefore - requiredRiseAfter;

  // Target profit loss calculations
  const targetReturnValue = finalTotalQuantity * targetExit;
  const targetProfitLossAmount = targetExit > 0 ? targetReturnValue - finalTotalInvestment : 0;
  const targetProfitLossRate =
    finalAvgPrice > 0 && targetExit > 0
      ? ((targetExit - finalAvgPrice) / finalAvgPrice) * 100
      : 0;

  // Diagnosis logic
  let diagnosisLevel: CalculationResult['diagnosisLevel'] = 'invalid';
  let diagnosisTitle = '입력 대기 중';
  let diagnosisMessage = '보유 수량, 현재 평단가 및 목표가를 입력하시면 탈출 진단 결과가 표시됩니다.';
  let diagnosisBadgeClass = 'bg-slate-100 text-slate-600 border-slate-200';

  if (targetExit > 0 && finalAvgPrice > 0) {
    if (requiredRiseAfter <= 0) {
      diagnosisLevel = 'easy';
      diagnosisTitle = '🟢 이미 본전/수익 구간 달성!';
      diagnosisMessage = `설정한 목표가(${formatCurrency(targetExit, state.assetMode)})가 최종 예상 평단가(${formatCurrency(finalAvgPrice, state.assetMode)})보다 높거나 같습니다! 목표가 도달 시 탈출 및 수익 창출이 가능합니다.`;
      diagnosisBadgeClass = 'bg-emerald-50 text-emerald-700 border-emerald-300';
    } else if (requiredRiseAfter <= 10) {
      diagnosisLevel = 'easy';
      diagnosisTitle = '🟢 탈출 용이 구간 (필요 상승률 10% 이내)';
      diagnosisMessage = `목표가에서 약 ${requiredRiseAfter.toFixed(1)}%만 반등하면 원금 회복 후 탈출이 가능합니다! 비교적 부담이 적은 희망적인 구간입니다.`;
      diagnosisBadgeClass = 'bg-emerald-50 text-emerald-700 border-emerald-300';
    } else if (requiredRiseAfter <= 25) {
      diagnosisLevel = 'moderate';
      diagnosisTitle = '🟡 적정 반등 구간 (필요 상승률 10%~25%)';
      diagnosisMessage = `목표가 대비 ${requiredRiseAfter.toFixed(1)}%의 반등이 필요한 구간입니다. 시장 거래량이 실리는 반등파동 시 탈출을 노려볼 수 있습니다.`;
      diagnosisBadgeClass = 'bg-amber-50 text-amber-700 border-amber-300';
    } else if (requiredRiseAfter <= 50) {
      diagnosisLevel = 'cautious';
      diagnosisTitle = '🟠 신중한 접근 필요 (필요 상승률 25%~50%)';
      diagnosisMessage = `목표가 대비 ${requiredRiseAfter.toFixed(1)}%의 강한 상승이 필요합니다. 물타기 비중이 과도해지지 않도록 리스크 관리가 필요합니다.`;
      diagnosisBadgeClass = 'bg-orange-50 text-orange-700 border-orange-300';
    } else {
      diagnosisLevel = 'high_risk';
      diagnosisTitle = '🔴 고위험 구간 (필요 상승률 50% 초과)';
      diagnosisMessage = `목표가 대비 ${requiredRiseAfter.toFixed(1)}%의 대형 폭등이 필요한 고위험 구간입니다. 원칙 없는 물타기는 투자금이 장기간 동결될 수 있으니 신중히 결정하세요.`;
      diagnosisBadgeClass = 'bg-rose-50 text-rose-700 border-rose-300';
    }
  }

  return {
    initialTotalQuantity: currentQty,
    initialTotalInvestment,
    additionalTotalQuantity,
    additionalTotalInvestment,
    finalTotalQuantity,
    finalTotalInvestment,
    finalAvgPrice,
    avgPriceReductionPercent,
    requiredRiseBefore,
    requiredRiseAfter,
    riseEasing,
    targetProfitLossAmount,
    targetProfitLossRate,
    diagnosisLevel,
    diagnosisTitle,
    diagnosisMessage,
    diagnosisBadgeClass,
  };
}
