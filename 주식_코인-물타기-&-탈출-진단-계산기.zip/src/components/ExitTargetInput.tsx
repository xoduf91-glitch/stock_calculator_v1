import React from 'react';
import { AssetMode, CalculationResult } from '../types';
import { ASSET_CONFIGS, formatCurrency, parseNumberInput } from '../utils/calculator';
import { Target, TrendingUp, AlertTriangle, CheckCircle2, Zap } from 'lucide-react';

interface ExitTargetInputProps {
  assetMode: AssetMode;
  targetExitPrice: number | '';
  calculationResult: CalculationResult;
  onChangeTargetExitPrice: (value: number | '') => void;
  onQuickSetTarget: (multiplier: number) => void;
}

export const ExitTargetInput: React.FC<ExitTargetInputProps> = ({
  assetMode,
  targetExitPrice,
  calculationResult,
  onChangeTargetExitPrice,
  onQuickSetTarget,
}) => {
  const config = ASSET_CONFIGS[assetMode];
  const {
    finalAvgPrice,
    requiredRiseBefore,
    requiredRiseAfter,
    riseEasing,
    targetProfitLossAmount,
    targetProfitLossRate,
    diagnosisTitle,
    diagnosisMessage,
    diagnosisBadgeClass,
  } = calculationResult;

  const hasTarget = typeof targetExitPrice === 'number' && targetExitPrice > 0;
  const hasFinalAvg = finalAvgPrice > 0;

  return (
    <div className="bg-indigo-600 rounded-2xl p-6 shadow-lg shadow-indigo-200 text-white transition-all">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4 pb-3 border-b border-white/20">
        <div>
          <h2 className="text-xs font-bold text-indigo-200 uppercase tracking-wider flex items-center gap-2">
            <Target className="w-4 h-4 text-white" />
            03. 반등 목표가 설정 & 탈출 진단
          </h2>
          <p className="text-xs text-indigo-100/90 mt-1">
            반등 예상 목표가에서 내 평단까지 필요한 상승률을 진단합니다.
          </p>
        </div>

        {hasFinalAvg && (
          <div className="flex flex-wrap gap-1 self-start sm:self-auto">
            <button
              onClick={() => onQuickSetTarget(0.9)}
              className="px-2.5 py-1 text-xs font-bold text-indigo-900 bg-white/90 hover:bg-white rounded-lg transition-colors"
            >
              예상평단 -10%
            </button>
            <button
              onClick={() => onQuickSetTarget(0.8)}
              className="px-2.5 py-1 text-xs font-bold text-indigo-900 bg-white/90 hover:bg-white rounded-lg transition-colors"
            >
              예상평단 -20%
            </button>
            <button
              onClick={() => onQuickSetTarget(1.0)}
              className="px-2.5 py-1 text-xs font-bold text-indigo-950 bg-amber-300 hover:bg-amber-200 rounded-lg transition-colors"
            >
              평단가 직행
            </button>
          </div>
        )}
      </div>

      {/* Input Field */}
      <div className="mb-5">
        <label className="block text-xs font-semibold text-indigo-100 uppercase mb-1.5">
          반등 목표가 / 예상 주가 ({config.symbol})
        </label>
        <div className="relative rounded-xl">
          <input
            type="text"
            inputMode="decimal"
            value={targetExitPrice === '' ? '' : targetExitPrice.toLocaleString('en-US', { maximumFractionDigits: config.decimals })}
            onChange={(e) => onChangeTargetExitPrice(parseNumberInput(e.target.value))}
            placeholder={`예: 반등 예상 주가 입력 (${config.symbol})`}
            className="w-full bg-indigo-500/40 border border-white/30 rounded-xl px-4 py-3 font-mono text-xl sm:text-2xl font-bold text-white placeholder-white/50 focus:bg-indigo-500/60 focus:border-white focus:outline-none transition-all pr-12"
          />
          <span className="absolute right-4 top-4 font-mono font-bold text-indigo-200 text-sm">
            {config.code}
          </span>
        </div>
      </div>

      {/* Diagnosis Display Panel */}
      {hasTarget && hasFinalAvg ? (
        <div className="space-y-4">
          {/* Main Diagnosis Badge & Message */}
          <div className="p-4 rounded-xl bg-white/10 border border-white/20 text-white backdrop-blur-xs">
            <div className="flex items-start gap-3">
              <div className="shrink-0 mt-0.5">
                {requiredRiseAfter <= 10 ? (
                  <CheckCircle2 className="w-5 h-5 text-emerald-300" />
                ) : (
                  <AlertTriangle className="w-5 h-5 text-amber-300" />
                )}
              </div>
              <div>
                <h3 className="font-extrabold text-sm sm:text-base">{diagnosisTitle}</h3>
                <p className="text-xs sm:text-sm mt-1 leading-relaxed opacity-95 text-indigo-100">
                  {diagnosisMessage}
                </p>
              </div>
            </div>
          </div>

          {/* Rise Rate Comparison Grid */}
          <div className="grid grid-cols-2 gap-3">
            {/* Before Averaging Down */}
            <div className="py-3 px-4 bg-white/10 rounded-xl border border-white/20 text-center">
              <span className="text-[10px] uppercase font-bold text-indigo-200 block mb-1">
                물타기 전 필요상승률
              </span>
              <span className="text-xl sm:text-2xl font-mono font-bold text-white block">
                +{requiredRiseBefore > 0 ? requiredRiseBefore.toFixed(1) : '0.0'}%
              </span>
            </div>

            {/* After Averaging Down */}
            <div className="py-3 px-4 bg-amber-400 text-indigo-950 rounded-xl border border-amber-300 text-center shadow-md">
              <span className="text-[10px] uppercase font-black text-indigo-900 block mb-1">
                물타기 후 필요상승률
              </span>
              <span className="text-xl sm:text-2xl font-mono font-black text-indigo-950 block">
                +{requiredRiseAfter > 0 ? requiredRiseAfter.toFixed(1) : '0.0'}%
              </span>
              {riseEasing > 0 && (
                <span className="text-[10px] font-extrabold bg-indigo-950 text-amber-300 px-1.5 py-0.5 rounded-md inline-block mt-1">
                  난이도 -{riseEasing.toFixed(1)}%p 완화!
                </span>
              )}
            </div>
          </div>

          {/* Visual Progress / Difficulty Gauge */}
          <div className="p-3.5 rounded-xl bg-indigo-950/70 border border-white/10 text-white">
            <div className="flex items-center justify-between text-xs mb-2">
              <span className="font-semibold text-indigo-200 flex items-center gap-1.5">
                <Zap className="w-3.5 h-3.5 text-amber-300" />
                탈출 난이도 게이지
              </span>
              <span className="font-mono text-amber-300 font-bold">
                +{requiredRiseAfter > 0 ? requiredRiseAfter.toFixed(1) : '0.0'}%
              </span>
            </div>

            <div className="w-full bg-indigo-900 h-2.5 rounded-full overflow-hidden p-0.5 relative">
              <div
                className={`h-full rounded-full transition-all duration-500 ${
                  requiredRiseAfter <= 10
                    ? 'bg-emerald-400'
                    : requiredRiseAfter <= 25
                    ? 'bg-amber-300'
                    : requiredRiseAfter <= 50
                    ? 'bg-orange-400'
                    : 'bg-rose-400'
                }`}
                style={{
                  width: `${Math.min(Math.max((requiredRiseAfter / 80) * 100, 5), 100)}%`,
                }}
              />
            </div>
          </div>

          {/* Target P&L Simulation */}
          <div className="p-3 rounded-xl bg-white/10 border border-white/15 flex items-center justify-between text-xs sm:text-sm">
            <div className="flex items-center gap-2 text-indigo-100 font-medium">
              <TrendingUp className="w-4 h-4 text-amber-300" />
              <span>목표가 도달 시 예상 손익</span>
            </div>

            <div className="text-right">
              <span
                className={`font-mono font-bold block ${
                  targetProfitLossAmount >= 0 ? 'text-emerald-300' : 'text-rose-300'
                }`}
              >
                {targetProfitLossAmount >= 0 ? '+' : ''}
                {formatCurrency(targetProfitLossAmount, assetMode)}
              </span>
              <span className="text-[11px] font-mono opacity-80 text-indigo-100">
                ({targetProfitLossRate >= 0 ? '+' : ''}
                {targetProfitLossRate.toFixed(2)}%)
              </span>
            </div>
          </div>
        </div>
      ) : (
        <div className="p-3.5 rounded-xl bg-white/10 border border-dashed border-white/20 text-center text-indigo-100 text-xs">
          💡 반등 예상 주가를 입력하시면 필요 상승률과 탈출 난이도를 진단해드립니다.
        </div>
      )}
    </div>
  );
};

