import React, { useState } from 'react';
import { Modal } from './Modal';
import { Mail, Shield, FileText } from 'lucide-react';

export const Footer: React.FC = () => {
  const [modalType, setModalType] = useState<'privacy' | 'terms' | 'contact' | null>(null);

  return (
    <footer className="mt-16 bg-slate-900 text-slate-400 py-12 px-4 sm:px-6 lg:px-8 border-t border-slate-800 text-xs">
      <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <span className="font-extrabold text-sm text-white tracking-tight">
              주식/코인 물타기 & 탈출 진단 계산기
            </span>
          </div>
          <p className="text-slate-500 max-w-md leading-relaxed">
            본 서비스에서 제공하는 모든 계산 결과 및 진단 정보는 참조용이며, 투자 결과에 대한 법적 책임의 근거로 사용될 수 없습니다. 투자 결정 및 리스크 관리는 투자자 본인의 판단하에 신중히 진행하시기 바랍니다.
          </p>
        </div>

        {/* Links */}
        <div className="flex flex-wrap items-center gap-4 sm:gap-6 text-slate-300 font-medium">
          <button
            onClick={() => setModalType('privacy')}
            className="hover:text-white transition-colors flex items-center gap-1"
          >
            <Shield className="w-3.5 h-3.5 text-indigo-400" />
            개인정보처리방침
          </button>

          <button
            onClick={() => setModalType('terms')}
            className="hover:text-white transition-colors flex items-center gap-1"
          >
            <FileText className="w-3.5 h-3.5 text-slate-400" />
            이용약관
          </button>

          <button
            onClick={() => setModalType('contact')}
            className="hover:text-white transition-colors flex items-center gap-1"
          >
            <Mail className="w-3.5 h-3.5 text-emerald-400" />
            문의하기
          </button>
        </div>
      </div>

      <div className="max-w-6xl mx-auto mt-8 pt-6 border-t border-slate-800/80 flex flex-col sm:flex-row items-center justify-between text-slate-500 text-[11px] gap-2">
        <span>© 2026 Smart Average Down & Exit Calculator. All rights reserved.</span>
        <span>Built for Smart Stock & Crypto Investors</span>
      </div>

      {/* Modals */}
      <Modal
        isOpen={modalType === 'privacy'}
        title="개인정보처리방침"
        onClose={() => setModalType(null)}
      >
        <p className="font-bold text-slate-900">1. 개인정보 수집 및 이용 목적</p>
        <p>
          본 서비스('주식/코인 물타기 계산기')는 사용자의 별도 회원가입을 요구하지 않으며, 사용자가 입력한 보유 주식 수량, 단가 등 모든 데이터는 <strong>사용자의 웹 브라우저 로컬 메모리 내에서만 단순 계산용으로 전송/처리</strong>되며 서버로 전송되거나 저장되지 않습니다.
        </p>
        <p className="font-bold text-slate-900 mt-3">2. 쿠키 및 제3자 광고 쿠키 사용</p>
        <p>
          Google을 포함한 제3자 제공업체는 사용자의 이전 웹사이트 방문 기록을 바탕으로 맞춤형 광고를 제공하기 위해 쿠키를 사용합니다.
        </p>
      </Modal>

      <Modal
        isOpen={modalType === 'terms'}
        title="서비스 이용약관"
        onClose={() => setModalType(null)}
      >
        <p className="font-bold text-slate-900">제 1 조 (목적)</p>
        <p>
          본 약관은 주식/코인 물타기 및 탈출 진단 계산기 서비스가 제공하는 온라인 금융 계산 도구의 이용 조건 및 절차에 관한 사항을 규정합니다.
        </p>
        <p className="font-bold text-slate-900 mt-3">제 2 조 (면책 조항)</p>
        <p>
          본 서비스는 단순 참고용 계산값을 제공하며, 어떠한 종목의 매수/매도 권유가 아닙니다. 계산 오차나 시세 변동으로 인해 발생하는 투자 손실에 대하여 본 사이트는 일체의 책임을 지지 않습니다.
        </p>
      </Modal>

      <Modal
        isOpen={modalType === 'contact'}
        title="문의하기"
        onClose={() => setModalType(null)}
      >
        <p>
          서비스 이용 중 개선 아이디어나 오류 신고, 피드백이 있으신 경우 아래 연락처로 언제든지 편하게 문의해 주세요.
        </p>
        <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 mt-2 font-mono text-slate-800 font-medium">
          📧 Email: support@calculator-app.com
        </div>
      </Modal>
    </footer>
  );
};
