import React from 'react';
import { AssetMode, CalculationResult } from '../types';
import { ASSET_CONFIGS, formatCurrency, formatNumber } from '../utils/calculator';
import { Calculator, Share2, RotateCcw, CheckCircle, ArrowDownRight, Layers } from 'lucide-react';

interface ResultDashboardProps {
  assetMode: AssetMode;
  calculationResult: CalculationResult;
  onReset: () => void;
  onCopyShareText: () => void;
  copied: boolean;
}

export const ResultDashboard: React.FC<ResultDashboardProps> = ({
  assetMode,
  calculationResult,
  onReset,
  onCopyShareText,
  copied,
}) => {
  const config = ASSET_CONFIGS[assetMode];

  const {
    initialTotalQuantity,
    initialTotalInvestment,
    additionalTotalQuantity,
    additionalTotalInvestment,
    finalTotalQuantity,
    finalTotalInvestment,
    finalAvgPrice,
    avgPriceReductionPercent,
  } = calculationResult;

  const hasData = finalTotalQuantity > 0;

  return (
    <div className="bg-slate-900 text-white rounded-3xl p-6 sm:p-8 shadow-xl relative overflow-hidden md:sticky md:top-24 border border-slate-800">
      {/* Decorative gradient blur background */}
      <div className="absolute top-0 right-0 w-48 h-48 bg-indigo-500/10 rounded-full blur-2xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-48 h-48 bg-emerald-500/10 rounded-full blur-2xl pointer-events-none" />

      <div className="relative z-10 space-y-6">
        <div>
          <div className="flex items-center justify-between">
            <span className="text-xs font-black uppercase tracking-[0.2em] text-slate-500">
              CALCULATED RESULT
            </span>

            <button
              onClick={onReset}
              className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
              title="초기화"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </div>

          <h2 className="text-sm font-semibold text-slate-400 mt-1">
            최종 예상 평균 단가
          </h2>

          <div className="flex items-baseline gap-2 mt-1">
            <div className="text-3xl sm:text-4xl font-mono font-bold tracking-tight text-white">
              {formatCurrency(finalAvgPrice, assetMode)}
            </div>

            {avgPriceReductionPercent > 0 && (
              <span className="inline-flex items-center gap-0.5 text-xs font-mono font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-md border border-emerald-500/20">
                <ArrowDownRight className="w-3.5 h-3.5" />
                -{avgPriceReductionPercent.toFixed(1)}%
              </span>
            )}
          </div>
        </div>

        {/* Breakdown Stats */}
        <div className="space-y-3 pt-4 border-t border-slate-800 text-sm">
          <div className="flex justify-between items-center text-slate-400">
            <span>총 보유 수량</span>
            <span className="font-mono text-slate-200 font-bold">
              {formatNumber(finalTotalQuantity, config.decimals)} {config.unitName}
            </span>
          </div>

          <div className="flex justify-between items-center text-slate-400">
            <span>기존 총 투자금액</span>
            <span className="font-mono text-slate-200 font-medium">
              {formatCurrency(initialTotalInvestment, assetMode)}
            </span>
          </div>

          <div className="flex justify-between items-center text-indigo-300">
            <span className="flex items-center gap-1 font-medium text-xs">
              <Layers className="w-3.5 h-3.5 text-indigo-400" /> 추가 매수 총 투자금
            </span>
            <span className="font-mono font-bold text-indigo-400">
              +{formatCurrency(additionalTotalInvestment, assetMode)}
            </span>
          </div>

          <div className="pt-3 border-t border-slate-800 flex justify-between items-center">
            <span className="font-bold text-slate-300">최종 총 투자금액</span>
            <span className="text-base sm:text-lg font-mono font-bold text-emerald-400">
              {formatCurrency(finalTotalInvestment, assetMode)}
            </span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="space-y-2 pt-2">
          <button
            onClick={onCopyShareText}
            disabled={!hasData}
            className={`w-full py-4 rounded-2xl font-bold flex items-center justify-center gap-2 transition-all shadow-md active:scale-98 text-sm ${
              hasData
                ? 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-indigo-900/40'
                : 'bg-slate-800 text-slate-500 cursor-not-allowed'
            }`}
          >
            {copied ? (
              <>
                <CheckCircle className="w-4 h-4 text-emerald-300" />
                <span>복사 완료! (공유 가능)</span>
              </>
            ) : (
              <>
                <Share2 className="w-4 h-4" />
                <span>계산 결과 복사하기</span>
              </>
            )}
          </button>

          <button
            onClick={onReset}
            className="w-full bg-slate-800 hover:bg-slate-700 py-3 rounded-2xl font-bold text-slate-400 hover:text-white transition-colors text-xs"
          >
            모든 입력값 초기화
          </button>
        </div>
      </div>
    </div>
  );
};

