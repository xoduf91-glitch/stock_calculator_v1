import React from 'react';
import { AssetMode, PurchaseTier } from '../types';
import { ASSET_CONFIGS, formatCurrency, parseNumberInput } from '../utils/calculator';
import { Plus, Trash2, Layers, Sparkles, AlertCircle } from 'lucide-react';

interface TierInputListProps {
  assetMode: AssetMode;
  tiers: PurchaseTier[];
  currentAvgPrice: number | '';
  currentQuantity: number | '';
  onAddTier: () => void;
  onRemoveTier: (id: string) => void;
  onUpdateTier: (id: string, field: 'quantity' | 'price', value: number | '') => void;
  onApplyPreset: (tierId: string, type: 'minus10' | 'minus20' | 'matchQty') => void;
}

export const TierInputList: React.FC<TierInputListProps> = ({
  assetMode,
  tiers,
  currentAvgPrice,
  currentQuantity,
  onAddTier,
  onRemoveTier,
  onUpdateTier,
  onApplyPreset,
}) => {
  const config = ASSET_CONFIGS[assetMode];

  return (
    <div className="bg-white rounded-2xl p-6 shadow-xs border border-slate-200 transition-all">
      <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-100">
        <h2 className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-2">
          <Layers className="w-4 h-4 text-indigo-600" />
          02. 추가 매수 계획 (물타기)
        </h2>

        <button
          onClick={onAddTier}
          className="text-xs font-bold text-indigo-600 hover:text-indigo-700 bg-indigo-50 hover:bg-indigo-100 px-3 py-1.5 rounded-xl transition-all inline-flex items-center gap-1"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>차수 추가</span>
        </button>
      </div>

      {tiers.length === 0 ? (
        <div className="text-center py-8 px-4 bg-slate-50/80 rounded-xl border border-dashed border-slate-200">
          <AlertCircle className="w-8 h-8 text-slate-400 mx-auto mb-2" />
          <p className="text-sm font-semibold text-slate-600">등록된 추가 매수 차수가 없습니다.</p>
          <p className="text-xs text-slate-400 mt-1">
            상단의 '+ 차수 추가' 버튼을 눌러 물타기 매수 계획을 등록해보세요.
          </p>
          <button
            onClick={onAddTier}
            className="mt-3 inline-flex items-center gap-1.5 px-4 py-2 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl transition-all shadow-xs"
          >
            <Plus className="w-3.5 h-3.5" /> 2차 추가 매수 생성하기
          </button>
        </div>
      ) : (
        <div className="space-y-3">
          {tiers.map((tier) => {
            const qty = typeof tier.quantity === 'number' ? tier.quantity : 0;
            const prc = typeof tier.price === 'number' ? tier.price : 0;
            const tierSubtotal = qty * prc;

            return (
              <div
                key={tier.id}
                className="p-4 rounded-xl bg-slate-50 border border-slate-200/90 relative group hover:border-indigo-300 transition-all"
              >
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-black text-indigo-600 bg-indigo-100/80 px-2 py-0.5 rounded-md">
                      {tier.tierNumber}차
                    </span>
                    <span className="text-xs font-bold text-slate-700 uppercase">
                      {tier.tierNumber}차 추가 매수
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    {tierSubtotal > 0 && (
                      <span className="text-xs font-mono font-bold text-slate-700">
                        소계: {formatCurrency(tierSubtotal, assetMode)}
                      </span>
                    )}

                    <button
                      onClick={() => onRemoveTier(tier.id)}
                      className="p-1 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                      title={`${tier.tierNumber}차 매수 삭제`}
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {/* Price */}
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-500 uppercase mb-1">
                      추가 매수 단가 ({config.symbol})
                    </label>
                    <div className="relative rounded-lg">
                      <input
                        type="text"
                        inputMode="decimal"
                        value={tier.price === '' ? '' : tier.price.toLocaleString('en-US', { maximumFractionDigits: config.decimals })}
                        onChange={(e) =>
                          onUpdateTier(tier.id, 'price', parseNumberInput(e.target.value))
                        }
                        placeholder="예: 42,000"
                        className="w-full bg-white border border-slate-200 rounded-lg px-3 py-2.5 font-mono text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 pr-10"
                      />
                      <span className="absolute right-3 top-2.5 text-xs font-semibold text-slate-400">
                        {config.symbol}
                      </span>
                    </div>
                  </div>

                  {/* Quantity */}
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-500 uppercase mb-1">
                      추가 매수 수량 ({config.unitName})
                    </label>
                    <div className="relative rounded-lg">
                      <input
                        type="text"
                        inputMode="decimal"
                        value={tier.quantity === '' ? '' : tier.quantity.toLocaleString('en-US', { maximumFractionDigits: config.decimals })}
                        onChange={(e) =>
                          onUpdateTier(tier.id, 'quantity', parseNumberInput(e.target.value))
                        }
                        placeholder="예: 50"
                        className="w-full bg-white border border-slate-200 rounded-lg px-3 py-2.5 font-mono text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 pr-10"
                      />
                      <span className="absolute right-3 top-2.5 text-xs font-semibold text-slate-400">
                        {config.unitName}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Quick Presets for this Tier */}
                {typeof currentAvgPrice === 'number' && currentAvgPrice > 0 && (
                  <div className="mt-2.5 pt-2 border-t border-slate-200/60 flex flex-wrap items-center justify-between gap-1 text-xs">
                    <span className="text-[11px] text-slate-400 flex items-center gap-1 font-medium">
                      <Sparkles className="w-3 h-3 text-amber-500" /> 빠른 입력:
                    </span>
                    <div className="flex flex-wrap gap-1">
                      <button
                        onClick={() => onApplyPreset(tier.id, 'minus10')}
                        className="px-2 py-0.5 rounded bg-white hover:bg-slate-100 text-slate-600 border border-slate-200 text-[11px] font-medium transition-colors"
                      >
                        -10%가
                      </button>
                      <button
                        onClick={() => onApplyPreset(tier.id, 'minus20')}
                        className="px-2 py-0.5 rounded bg-white hover:bg-slate-100 text-slate-600 border border-slate-200 text-[11px] font-medium transition-colors"
                      >
                        -20%가
                      </button>
                      {typeof currentQuantity === 'number' && currentQuantity > 0 && (
                        <button
                          onClick={() => onApplyPreset(tier.id, 'matchQty')}
                          className="px-2 py-0.5 rounded bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 text-[11px] font-bold transition-colors"
                        >
                          1:1 동일수량({currentQuantity}{config.unitName})
                        </button>
                      )}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

