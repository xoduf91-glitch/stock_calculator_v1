import React from 'react';
import { AssetMode } from '../types';
import { ASSET_CONFIGS, formatCurrency, parseNumberInput } from '../utils/calculator';
import { Wallet, Clock } from 'lucide-react';

interface HoldingsInputProps {
  assetMode: AssetMode;
  currentQuantity: number | '';
  currentAvgPrice: number | '';
  onChangeQuantity: (value: number | '') => void;
  onChangeAvgPrice: (value: number | '') => void;
}

export const HoldingsInput: React.FC<HoldingsInputProps> = ({
  assetMode,
  currentQuantity,
  currentAvgPrice,
  onChangeQuantity,
  onChangeAvgPrice,
}) => {
  const config = ASSET_CONFIGS[assetMode];
  const totalInvested =
    typeof currentQuantity === 'number' && typeof currentAvgPrice === 'number'
      ? currentQuantity * currentAvgPrice
      : 0;

  return (
    <div className="bg-white rounded-2xl p-6 shadow-xs border border-slate-200 transition-all">
      <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-100">
        <h2 className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-2">
          <Clock className="w-4 h-4 text-indigo-600" />
          01. 현재 보유 상태 (기존 주식/코인)
        </h2>

        {totalInvested > 0 && (
          <div className="text-right">
            <span className="text-[11px] text-slate-400 font-medium block">기존 총 매수금액</span>
            <span className="text-xs font-mono font-bold text-slate-800">
              {formatCurrency(totalInvested, assetMode)}
            </span>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {/* Current Avg Price Input */}
        <div>
          <label className="block text-xs font-semibold text-slate-500 uppercase mb-1.5">
            현재 매수 평균 단가 ({config.symbol})
          </label>
          <div className="relative rounded-xl">
            <input
              type="text"
              inputMode="decimal"
              value={currentAvgPrice === '' ? '' : currentAvgPrice.toLocaleString('en-US', { maximumFractionDigits: config.decimals })}
              onChange={(e) => onChangeAvgPrice(parseNumberInput(e.target.value))}
              placeholder={`예: 50,000`}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 font-mono text-base sm:text-lg text-slate-900 focus:bg-white focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-all pr-12"
            />
            <span className="absolute right-4 top-3.5 text-slate-400 font-bold text-sm">
              {config.symbol}
            </span>
          </div>
        </div>

        {/* Quantity Input */}
        <div>
          <label className="block text-xs font-semibold text-slate-500 uppercase mb-1.5">
            현재 보유 수량 ({config.unitName})
          </label>
          <div className="relative rounded-xl">
            <input
              type="text"
              inputMode="decimal"
              value={currentQuantity === '' ? '' : currentQuantity.toLocaleString('en-US', { maximumFractionDigits: config.decimals })}
              onChange={(e) => onChangeQuantity(parseNumberInput(e.target.value))}
              placeholder={`예: 100`}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 font-mono text-base sm:text-lg text-slate-900 focus:bg-white focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-all pr-12"
            />
            <span className="absolute right-4 top-3.5 text-slate-400 font-bold text-sm">
              {config.unitName}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};

