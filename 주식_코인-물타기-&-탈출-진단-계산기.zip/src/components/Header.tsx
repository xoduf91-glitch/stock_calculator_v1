import React from 'react';
import { AssetMode } from '../types';
import { TrendingDown, Coins, DollarSign, RotateCcw, ShieldCheck, Activity } from 'lucide-react';

interface HeaderProps {
  assetMode: AssetMode;
  onAssetModeChange: (mode: AssetMode) => void;
  onReset: () => void;
}

export const Header: React.FC<HeaderProps> = ({ assetMode, onAssetModeChange, onReset }) => {
  return (
    <header className="bg-white border-b border-slate-200 px-4 sm:px-8 py-4 shadow-2xs sticky top-0 z-30">
      <div className="max-w-6xl mx-auto flex flex-col md:flex-row md:items-center justify-between gap-4">
        {/* Brand Logo & Title */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 bg-indigo-600 rounded-xl flex items-center justify-center shadow-xs text-white shrink-0">
              <TrendingDown className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-lg sm:text-xl font-extrabold tracking-tight text-slate-900 flex items-center gap-2">
                StockFlow <span className="font-normal text-slate-400 text-sm hidden sm:inline">| 주식·코인 탈출 진단기</span>
              </h1>
              <p className="text-[11px] text-slate-500 font-medium sm:hidden">
                주식·코인 물타기(평단가) & 탈출 진단 계산기
              </p>
            </div>
          </div>

          <button
            onClick={onReset}
            className="md:hidden inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-xl transition-all"
            title="초기화"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>초기화</span>
          </button>
        </div>

        {/* Mode Selector & Reset Button */}
        <div className="flex items-center justify-between md:justify-end gap-3 flex-wrap">
          {/* Asset Mode Selection Tabs */}
          <div className="bg-slate-100 p-1 rounded-2xl border border-slate-200/80 inline-flex flex-wrap gap-1">
            <button
              onClick={() => onAssetModeChange('stock_krw')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                assetMode === 'stock_krw'
                  ? 'bg-white text-indigo-600 shadow-xs border border-slate-200/60'
                  : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
              <span>국내 주식 (₩)</span>
            </button>

            <button
              onClick={() => onAssetModeChange('stock_usd')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                assetMode === 'stock_usd'
                  ? 'bg-white text-indigo-600 shadow-xs border border-slate-200/60'
                  : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <DollarSign className="w-3.5 h-3.5 text-amber-500" />
              <span>해외 주식 ($)</span>
            </button>

            <button
              onClick={() => onAssetModeChange('crypto')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                assetMode === 'crypto'
                  ? 'bg-white text-indigo-600 shadow-xs border border-slate-200/60'
                  : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <Coins className="w-3.5 h-3.5 text-cyan-500" />
              <span>코인 (소수점)</span>
            </button>
          </div>

          <button
            onClick={onReset}
            className="hidden md:inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-xl transition-all"
            title="모든 입력값 초기화"
          >
            <RotateCcw className="w-3.5 h-3.5 text-slate-500" />
            <span>초기화</span>
          </button>
        </div>
      </div>
    </header>
  );
};

