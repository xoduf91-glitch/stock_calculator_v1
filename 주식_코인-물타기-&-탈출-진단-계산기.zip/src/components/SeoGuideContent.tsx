import React, { useState } from 'react';
import { BookOpen, ShieldAlert, HelpCircle, ChevronDown, ChevronUp, Sparkles, AlertTriangle } from 'lucide-react';

export const SeoGuideContent: React.FC = () => {
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  const toggleFaq = (index: number) => {
    setOpenFaq(openFaq === index ? null : index);
  };

  return (
    <div className="mt-12 space-y-8">
      {/* AdSense Placement Area 1 */}
      <div className="bg-slate-100/80 border border-slate-200 rounded-2xl p-4 text-center text-slate-400 text-xs font-mono">
        <span className="block font-semibold text-slate-500 mb-1">[광고 영역 / AdSense Sponsor Banner]</span>
        <span>Google AdSense Responsive Content Unit</span>
      </div>

      {/* Section 1: Water-dilution (Weighted Average) Formula & Principles */}
      <section className="bg-white rounded-2xl p-6 border border-slate-200/80 shadow-xs">
        <div className="flex items-center gap-2.5 mb-4 pb-3 border-b border-slate-100">
          <div className="w-8 h-8 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center">
            <BookOpen className="w-4 h-4" />
          </div>
          <h2 className="text-lg font-bold text-slate-900">
            물타기(가중평균 단가) 계산 공식 및 투자 원리
          </h2>
        </div>

        <div className="text-sm text-slate-600 leading-relaxed space-y-3">
          <p>
            주식 및 암호화폐(코인) 시장에서 <strong className="text-slate-900">물타기(Average Down)</strong>란, 보유 종목의 주가가 하락했을 때 추가 매수하여 매수 평균 단가(평단가)를 낮추는 전략입니다. 단순히 산술평균으로 단가를 반으로 나누는 것이 아니라, <strong className="text-indigo-600">구매한 수량에 따른 가중평균(Weighted Average)</strong>으로 계산해야 정확한 예상 평단가를 산출할 수 있습니다.
          </p>

          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 font-mono text-xs sm:text-sm text-slate-800 my-2 overflow-x-auto">
            <span className="block text-indigo-600 font-bold mb-1">[ 가중평균 평단가 공식 ]</span>
            <code>
              최종 평단가 = (기존 수량 × 기존 평단가 + 추가 수량 × 추가 단가) ÷ (기존 수량 + 추가 수량)
            </code>
          </div>

          <p className="text-xs text-slate-500">
            평단가가 낮아지면 주가가 원래 매수가까지 복귀하지 않더라도, 상대적으로 적은 반등폭(예: 10~15% 반등)만으로 원금을 회복하거나 수익 전환 탈출이 가능해집니다.
          </p>
        </div>
      </section>

      {/* Section 2: 3 Precautions when Averaging Down */}
      <section className="bg-white rounded-2xl p-6 border border-slate-200/80 shadow-xs">
        <div className="flex items-center gap-2.5 mb-4 pb-3 border-b border-slate-100">
          <div className="w-8 h-8 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center">
            <ShieldAlert className="w-4 h-4" />
          </div>
          <h2 className="text-lg font-bold text-slate-900">
            원칙 없는 물타기 주의사항 3가지
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/80">
            <div className="flex items-center gap-2 font-bold text-slate-900 text-sm mb-2 text-rose-600">
              <AlertTriangle className="w-4 h-4" />
              1. 현금 비중 고갈 및 몰빵 위험
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">
              하락장 초기에 무작정 시드머니를 다 털어 물타기하면, 정작 진바닥이 왔을 때 대응할 자금이 소진되어 장기간 강제 손절을 지켜봐야 할 수 있습니다.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/80">
            <div className="flex items-center gap-2 font-bold text-slate-900 text-sm mb-2 text-amber-600">
              <AlertTriangle className="w-4 h-4" />
              2. 기업 상장폐지/악재성 하락 여부
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">
              기업의 펀더멘털 훼손, 횡령, 상장폐지 우려 또는 코인 유의종목 지정 등 구조적 악재로 떨어지는 종목에 대한 물타기는 밑져야 본전이 아닌 큰 손실로 이어집니다.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/80">
            <div className="flex items-center gap-2 font-bold text-slate-900 text-sm mb-2 text-indigo-600">
              <AlertTriangle className="w-4 h-4" />
              3. 분할 매수 계획 없는 조급함
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">
              지속적인 하락 추세선이 꺾이지 않았는데 감정적으로 매수하지 마세요. 반드시 주요 지지선 확증 및 2차, 3차 분할 매수 시나리오를 미리 세워둬야 합니다.
            </p>
          </div>
        </div>
      </section>

      {/* Section 3: FAQ (Accordion Style) */}
      <section className="bg-white rounded-2xl p-6 border border-slate-200/80 shadow-xs">
        <div className="flex items-center gap-2.5 mb-4 pb-3 border-b border-slate-100">
          <div className="w-8 h-8 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
            <HelpCircle className="w-4 h-4" />
          </div>
          <h2 className="text-lg font-bold text-slate-900">
            자주 묻는 질문 (FAQ)
          </h2>
        </div>

        <div className="space-y-3">
          {/* FAQ 1 */}
          <div className="border border-slate-200 rounded-xl overflow-hidden">
            <button
              onClick={() => toggleFaq(0)}
              className="w-full p-4 text-left font-semibold text-slate-800 text-sm sm:text-base flex justify-between items-center bg-slate-50 hover:bg-slate-100 transition-colors"
            >
              <span>Q1. 물타기 후 평단가가 낮아지면 무조건 이득인가요?</span>
              {openFaq === 0 ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
            </button>
            {openFaq === 0 && (
              <div className="p-4 bg-white text-xs sm:text-sm text-slate-600 leading-relaxed border-t border-slate-200">
                A. 아닙니다. 평단가가 낮아진 것은 착시일 뿐, <strong>총 매수 금액(총 원금)과 투자 비중이 늘어난 상태</strong>입니다. 따라서 주가가 더 하락할 경우 이전보다 원금 손실 폭이 배로 커질 수 있습니다. 반등 가능성이 확실한 구간에서 손절 라인을 설정하고 물타기를 진행하는 것이 중요합니다.
              </div>
            )}
          </div>

          {/* FAQ 2 */}
          <div className="border border-slate-200 rounded-xl overflow-hidden">
            <button
              onClick={() => toggleFaq(1)}
              className="w-full p-4 text-left font-semibold text-slate-800 text-sm sm:text-base flex justify-between items-center bg-slate-50 hover:bg-slate-100 transition-colors"
            >
              <span>Q2. 주식과 코인 물타기 계산 방식이 다른가요?</span>
              {openFaq === 1 ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
            </button>
            {openFaq === 1 && (
              <div className="p-4 bg-white text-xs sm:text-sm text-slate-600 leading-relaxed border-t border-slate-200">
                A. 가중평균 계산 공식 자체는 동일합니다. 다만 암호화폐(비트코인, 이더리움 등)의 경우 <strong>0.0001개 단위의 소수점 수량 매수</strong>가 가능하므로, 수량 정밀도와 최소 주문 금액 규칙을 고려해야 합니다. 본 계산기는 상단 탭에서 '암호화폐/코인' 모드를 지원하여 소수점 수량에 최적화되어 있습니다.
              </div>
            )}
          </div>
        </div>
      </section>

      {/* AdSense Placement Area 2 */}
      <div className="bg-slate-100/80 border border-slate-200 rounded-2xl p-4 text-center text-slate-400 text-xs font-mono">
        <span className="block font-semibold text-slate-500 mb-1">[하단 광고 영역 / Bottom AdSense Placement]</span>
        <span>Google AdSense Banner Area</span>
      </div>
    </div>
  );
};
